package quizz;
public class Quizz {

    public static void main(String[] args) {
       new LoginPage();
    }
    
}
